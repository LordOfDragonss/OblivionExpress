using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraHandler : MonoBehaviour
{
    public CinemachineVirtualCamera mainCam;
    public Camera mainCamera;
    public LayerMask FollowMask;
    public LayerMask HideMask;
    public CinemachineVirtualCamera[] cameras;
    void Awake()
    {
        cameras = FindObjectsOfType<CinemachineVirtualCamera>();
        foreach (var cam in cameras)
        {
            if (cam != mainCam)
                cam.enabled = false;
        }
    }

    public void RemoveDoorWall()
    {
        mainCamera.cullingMask = FollowMask;
    }

    public void HideAngle()
    {
        mainCamera.cullingMask = HideMask;
    }

    public void SwitchToCamera(CinemachineVirtualCamera CamToSwap)
    {
        foreach (var cam in cameras)
        {
            if (cam == CamToSwap)
            {
                CamToSwap.enabled = true;
                cam.enabled = true;
            }
            else
            {
                cam.enabled = false;
            }

        }
    }
}
