using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEditor.Progress;

public class CourierMovement : MonoBehaviour
{
    public GameObject[] Locations;
    [SerializeField] int Locationindex;
    [SerializeField] CinemachineVirtualCamera followCam;
    [SerializeField] CinemachineVirtualCamera murderCam;
    public float Speed;
    float OgSpeed;
    [SerializeField] float MurderSpeed;
    public float rotationSpeed;
    [SerializeField] bool cyclestarted;
    [SerializeField] float timer;
    public float TimeTillCourier;
    public CameraHandler CameraHandler;
    public float LocationWaitTime;
    public bool murderStart;
    public bool murdering;
    public float MurderTime;
    public Victim firstVictim;
    // Start is called before the first frame update
    void Start()
    {
        Locationindex = 0;
        cyclestarted = false;
        murderStart = true;
        OgSpeed = Speed;
        AudioManager.PlayCall("ShadowOfDeath");
    }

    // Update is called once per frame
    void Update()
    {
        if (murderStart)
        {
            AudioManager.PlayCall("Breath");
            CameraHandler.SwitchToCamera(murderCam);
            murderStart =false;
            murdering = true;
        }
        if (murdering)
        {
            Speed = MurderSpeed;
            timer += Time.deltaTime;
            firstVictim.Dissapear();
            transform.position = Vector3.MoveTowards(transform.position, Locations[Locationindex].transform.position, Speed * Time.deltaTime);
            transform.rotation = Quaternion.Slerp(transform.rotation, Locations[Locationindex].transform.rotation, rotationSpeed * Time.deltaTime);
            if (timer >= MurderTime)
            {
                timer = 0;
                CameraHandler.SwitchToCamera(CameraHandler.mainCam);
                murdering = false;
            }
        }
        CameraHandler.SwitchToCamera(murderCam);
        if (!cyclestarted && !murdering)
            timer += Time.deltaTime;
        if (timer >= TimeTillCourier && !cyclestarted)
        {
            cyclestarted = true;
            StartCycle();
            AudioManager.PlayCall("Horns");
        }
        if (cyclestarted)
        {
            StartCoroutine(MoveTroughCycle());
            cyclestarted = false;
        }
    }

    public void StartCycle()
    {
        Speed = OgSpeed;
        CameraHandler.SwitchToCamera(followCam);
        CameraHandler.RemoveDoorWall();
    }

    public IEnumerator MoveTroughCycle()
    {
        if (Locationindex >= Locations.Length - 1)
        {
            yield return null;
        }
        transform.position = Vector3.MoveTowards(transform.position, Locations[Locationindex].transform.position, Speed * Time.deltaTime);
        transform.rotation = Quaternion.Slerp(transform.rotation, Locations[Locationindex].transform.rotation, rotationSpeed * Time.deltaTime);
        yield return new WaitForSeconds(LocationWaitTime);
        if (transform.position == Locations[Locationindex].transform.position)
        {
            Locationindex++;
        }

    }
}
