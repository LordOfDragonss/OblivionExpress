using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HideObject : MonoBehaviour
{
    public CinemachineVirtualCamera cam;
    public CameraHandler CameraHandler;
    public Outline outline;
    [SerializeField] private GameObject HidingSpot;
    private Player player;

    private void Start()
    {
        player = FindObjectOfType<Player>();
    }

    private void OnMouseEnter()
    {
        outline.OutlineMode = Outline.Mode.OutlineAll;
    }

    private void OnMouseDown()
    {
        Hide();
    }
    private void OnMouseExit()
    {
        outline.OutlineMode = Outline.Mode.OutlineHidden;
    }

    private void Hide()
    {
        CameraHandler.SwitchToCamera(cam);
        CameraHandler.HideAngle();
        player.Hide(HidingSpot);
    }
}
