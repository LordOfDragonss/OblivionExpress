using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public bool isHiding;
    public void Hide(GameObject Spot)
    {
        transform.position = Spot.transform.position;
        if(Spot.transform.rotation != Quaternion.identity)
        {
            transform.rotation = Spot.transform.rotation;
        }

    }
}
