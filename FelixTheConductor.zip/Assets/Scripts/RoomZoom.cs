using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class RoomZoom : MonoBehaviour
{
    [SerializeField] CinemachineVirtualCamera RoomCam;
    [SerializeField] CameraHandler cameraHandler;
    public Outline[] outlines;
    private void OnMouseDown()
    {
        cameraHandler.SwitchToCamera(RoomCam);
    }
    private void OnMouseEnter()
    {
        foreach(var outline  in outlines)
        {
            outline.OutlineMode = Outline.Mode.OutlineAll;
        }

    }
    private void OnMouseExit()
    {
        foreach (var outline in outlines)
        {
            outline.OutlineMode = Outline.Mode.OutlineHidden;
        }
    }
}
