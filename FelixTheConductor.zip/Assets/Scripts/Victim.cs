using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Victim : MonoBehaviour
{
    public SpriteRenderer[] sprites;
    [SerializeField] bool Dissapearing;
    private void Start()
    {
        Dissapearing = false;
    }
    private void Update()
    {
        if (Dissapearing)
        {
            foreach (var sprite in sprites)
            {
                Color color = sprite.color;
                color.a -= 0.1f * Time.deltaTime;
                if(color.a < 0f) color.a = 0f;
                sprite.color = color;
            }
        }
    }
    public void Dissapear()
    {
        Dissapearing = true;
    }
}
